require("scripts.autotracking.item_mapping")
require("scripts.autotracking.location_mapping")

CUR_INDEX = -1
--SLOT_DATA = nil

ALL_LOCATIONS = {}
SLOT_DATA = {}

MANUAL_CHECKED = true
ROOM_SEED = "default"
TROLL_PLAYER = false

if Highlight then
    HIGHLIGHT_LEVEL= {
        [0] = Highlight.Unspecified,
        [10] = Highlight.NoPriority,
        [20] = Highlight.Avoid,
        [30] = Highlight.Priority,
        [40] = Highlight.None,
        [100] = Highlight.Unspecified, --Filler
        [101] = Highlight.Priority, --Progression
        [102] = Highlight.NoPriority, --Useful
        [103] = Highlight.Priority, -- Prog + Useful
        [104] = Highlight.Avoid, --Trap
        [105] = Highlight.Priority, -- Prog + Trap
        [106] = Highlight.NoPriority, -- Useful + Trap
        [107] = Highlight.Priority, -- Prog + Useful + Trap
    }
end

Troll_Lookup = {
    ["solarcell"] = true,
    ["earthor"] = true,
}


BOSS_STATES = {
	[0] = false,
	[1] = false,
    [2] = false,
    [3] = false,
    [4] = false,
    [5] = false,
    [6] = false
}
BOSS_LOCATION_TO_INDEX = {
    [9001] = 0, -- Amazon Boss
    [9002] = 1, -- Antarctica Boss
    [9003] = 2, -- Deep Amazon Boss
    [9004] = 3, -- Mid Atlantic Boss
    [9005] = 4, -- Alaska Complete
    [9006] = 5, -- Starship Boss
    [9007] = 6, -- Pacific Island Boss
}
BOSS_STORAGE_KEYS = {}
BOSS_STATES_RECEIVED = {}




---function to build a pretty-printable representation of a provided table
---@param o table
---@param depth? integer
---@return string
function DumpTable(o, depth)
    if depth == nil then
        depth = 0
    end
    if type(o) == 'table' then
        local tabs = ('\t'):rep(depth)
        local tabs2 = ('\t'):rep(depth + 1)
        local s = '{\n'
        for k, v in pairs(o) do
            if type(k) ~= 'number' then
                k = '"' .. k .. '"'
            end
            s = s .. tabs2 .. '[' .. k .. '] = ' .. DumpTable(v, depth + 1) .. ',\n'
        end
        return s .. tabs .. '}'
    else
        return tostring(o)
    end
end

---helper function that gets called when a LocationSection has changed state.
---checks if the interaction was from the server or manual.
---if manual, puts it into a cache for keeping that LocationSection toggled when reconnecting
---@param location LocationSection
function LocationHandler(location)
    if MANUAL_CHECKED then
        local custom_storage_item = Tracker:FindObjectForCode("manual_location_storage").ItemState
        if not custom_storage_item then
            return
        end
        if Archipelago.PlayerNumber == -1 then -- not connected
            if ROOM_SEED ~= "default" then -- seed is from previous connection
                ROOM_SEED = "default"
                custom_storage_item.MANUAL_LOCATIONS["default"] = {}
            else -- seed is default
            end
        end
        local full_path = location.FullID
        if not custom_storage_item.MANUAL_LOCATIONS[ROOM_SEED] then
            custom_storage_item.MANUAL_LOCATIONS[ROOM_SEED] = {}
        end
        if location.AvailableChestCount < location.ChestCount then --add to list
            -- print("add to list")
            custom_storage_item.MANUAL_LOCATIONS[ROOM_SEED][full_path] = location.AvailableChestCount
        else --remove from list of set back to max chestcount
            -- print("remove from list")
            custom_storage_item.MANUAL_LOCATIONS[ROOM_SEED][full_path] = nil
        end
    end
    -- local custom_storage_item = Tracker:FindObjectForCode("manual_location_storage").ItemState
    -- print(DumpTable(storage_item.ItemState.MANUAL_LOCATIONS))
    ForceUpdate() --
end

--function to force an update even if the interaction within poptracker noramlly would not call for a state update
function ForceUpdate()
    local update = Tracker:FindObjectForCode("update")
    if update == nil then
        return
    end
    update.Active = not update.Active
end


---resets or updates a given item back to default or what's saved for the given seed in the pseudo-cache LuaItems
---@param item_code JsonItem|string Tracker:FindObjectForCode(item) return object
---@param item_type string|nil table of the ItemCode and extra parameters from the Item_Mapping.lau
---@param consumable_multiplier integer|nil table of the ItemCode and extra parameters from the Item_Mapping.lua
---@param item_id integer AP-ID of the item from ITEM_MAPPING
---@param reset boolean|nil flag to update or reset the item false=update, true=reset, nil=update
local function ItemUpdate(item_code, item_type, consumable_multiplier, item_id, reset)
    local item_obj = nil

    if type(item_code) == "string" then
        item_obj = Tracker:FindObjectForCode(item_code)
    else
        item_obj = item_code
    end
    if item_obj == nil then
        print(string.format("ItemUpdate: could not find item_object for code %s", item_code))
        return
    end

    if item_type == nil then
        item_type = item_obj.Type
    end

    if item_type == "toggle" then
        item_obj.Active = not reset --reset and false or true
    elseif item_type == "progressive" then
        item_obj.CurrentStage = reset and 0 or (item_obj.CurrentStage + 1)
    elseif item_type == "consumable" then
        item_obj.AcquiredCount = reset and (item_obj.MinCount or 0) or
        (item_obj.AcquiredCount + item_obj.Increment * (consumable_multiplier or 1))
    elseif item_type == "progressive_toggle" then
        item_obj.CurrentStage = reset and 0 or (item_obj.CurrentStage + 1)
        item_obj.Active = not reset -- reset and false or true
    end
	UpdateMiniconCounter()
end


---resets or updates a given location back to default or whats saved for the gives seed in the pseudo-cache LuaItems
---@param location_obj LocationSection Tracker:FindObjectForCode(location) return object
---@param custom_storage_item table Reference for the custom LuaItem CachesItems
---@param location_id integer AP-ID of the location from LOCATION_MAPPING
---@param reset boolean flag to update or reset the item false=update, true=reset, nil=update
local function LocationUpdate(location_obj, custom_storage_item, location_id, reset)
    ---@cast location_obj LocationSection

    if reset then --reset
        if custom_storage_item and custom_storage_item.MANUAL_LOCATIONS[ROOM_SEED][location_obj.FullID] then
            location_obj.AvailableChestCount = custom_storage_item.MANUAL_LOCATIONS[ROOM_SEED][location_obj.FullID]
        else
            location_obj.AvailableChestCount = location_obj.ChestCount
        end
        location_obj.Highlight = HIGHLIGHT_LEVEL[40]
    else --update
        (location_obj --[[@as LocationSection]]).AvailableChestCount = location_obj.AvailableChestCount - 1
    end
	
	UpdateBossesBeaten()
end


-- Returns true if Archipelago reports this location as checked.
local function IsLocationChecked(location_id)
	for _, checked_id in pairs(Archipelago.CheckedLocations) do
		if checked_id == location_id then
			return true
		end
	end
	return false
end

-- Updates one boss location using both the checked-location ID
-- and the corresponding boolean received from DataStorage.
local function UpdateBossLocation(location_id)
	-- Only use boss server data when the goal is Bosses.
    if not SLOT_DATA or tonumber(SLOT_DATA.goal_option) ~= 1 then
        return
    end
	
	local boss_index = BOSS_LOCATION_TO_INDEX[location_id]

	if boss_index == nil then
		return
	end

	-- Do not update the location until its server value has arrived.
	if not BOSS_STATES_RECEIVED[boss_index] then
		return
	end

	local location_array = LOCATION_MAPPING[location_id]
	if not location_array then
		return
	end

	local should_be_checked =
		IsLocationChecked(location_id)
		and BOSS_STATES[boss_index] == true
		
	
	for _, location_code in pairs(location_array) do
		if type(location_code) == "string"
			and location_code:sub(1, 1) == "@" then

			local location_obj =
				Tracker:FindObjectForCode(location_code)

			if location_obj then
				if should_be_checked then
					-- Boss defeated AND location sent.
					location_obj.AvailableChestCount =
						math.max(0, location_obj.ChestCount - 1)
				else
					-- Either the location was not sent,
					-- or the server says the boss is not defeated.
					location_obj.AvailableChestCount =
						location_obj.ChestCount
				end
			end
		end
	end

	UpdateBossesBeaten()
end


-- Reconcile every boss location after initial values arrive.
local function UpdateAllBossLocations()
	for location_id, _ in pairs(BOSS_LOCATION_TO_INDEX) do
		UpdateBossLocation(location_id)
	end

	ForceUpdate()
end


--- Function to prepare custom LuaItems for caching, check for mischieve/traps, subscribe to datastorage
local function PreOnClear()
    PLAYER_ID = Archipelago.PlayerNumber or -1
	TEAM_NUMBER = Archipelago.TeamNumber or 0
    if PLAYER_ID > -1 then
        for key, _ in pairs(Troll_Lookup) do
            if string.find(string.lower(Archipelago:GetPlayerAlias(PLAYER_ID)), key, 1, true) ~= nil then
                TROLL_PLAYER = true
                break
            end
        end

        --- example for how to build a date object and how to check current user's date against it
        --local start_day_range = BuildTimeObj(nil, 3 , 31)
        --local end_day_range = BuildTimeObj(nil, 4 , 5)
        --DATE_CHECK_PASSED = CheckDateRange(start_day_range, end_day_range, os.time())
        --if TROLL_PLAYER == false and DATE_CHECK_PASSED then
        --    TROLL_PLAYER = true
        --end

        if #ALL_LOCATIONS > 0 then
            ALL_LOCATIONS = {}
        end
        for _, value in pairs(Archipelago.MissingLocations) do
            table.insert(ALL_LOCATIONS, #ALL_LOCATIONS + 1, value)
        end

        for _, value in pairs(Archipelago.CheckedLocations) do
            table.insert(ALL_LOCATIONS, #ALL_LOCATIONS + 1, value)
        end
        ---add more of those for other datastorage keys
        HINTS_ID = "_read_hints_"..TEAM_NUMBER.."_"..PLAYER_ID
        Archipelago:SetNotify({HINTS_ID}) --{HINTS_ID, other vars, ...}
        Archipelago:Get({HINTS_ID}) --{HINTS_ID, other vars, ...}
    end


    -- print(Archipelago.Seed)
    local seed_base = (Archipelago.Seed or tostring(#ALL_LOCATIONS)).."_"..Archipelago.TeamNumber.."_"..Archipelago.PlayerNumber
    if ROOM_SEED == "default" or ROOM_SEED ~= seed_base then -- seed is default or from previous connection

        ROOM_SEED = seed_base --something like 2345_0_12
        for _, custom_item_code in pairs({"manual_location_storage"}) do -- add more to the table if you created more storage cache items
            local custom_storage_item = Tracker:FindObjectForCode(custom_item_code).ItemState
            if custom_storage_item then
                if #custom_storage_item.MANUAL_LOCATIONS > 10 then
                    custom_storage_item.MANUAL_LOCATIONS[custom_storage_item.MANUAL_LOCATIONS_ORDER[1]] = nil
                    table.remove(custom_storage_item.MANUAL_LOCATIONS_ORDER, 1)
                end
                if custom_storage_item.MANUAL_LOCATIONS[ROOM_SEED] == nil then
                    custom_storage_item.MANUAL_LOCATIONS[ROOM_SEED] = {}
                    table.insert(custom_storage_item.MANUAL_LOCATIONS_ORDER, ROOM_SEED)
                end
            end
        end
    else -- seed is from previous connection
        -- do nothing
    end
end

---function that gets called when the pack connects to an AP server
---@param slot_data? table Slotdata send from AP server for the specific user/slot
function OnClear(slot_data)
    MANUAL_CHECKED = false
	
	-- Clear any boss values from the previous connection.
    for boss_index = 0, 6 do
        BOSS_STATES[boss_index] = false
        BOSS_STATES_RECEIVED[boss_index] = false
    end

    BOSS_STORAGE_KEYS = {}
	
    local custom_storage_item = Tracker:FindObjectForCode("manual_location_storage").ItemState
    if custom_storage_item == nil then
        CreateLuaManualStorageItem("manual_location_storage")
        custom_storage_item = Tracker:FindObjectForCode("manual_location_storage").ItemState
    end
    -- repeat that here for every cache-storage item you create just to be safe

    PreOnClear()

    ScriptHost:RemoveWatchForCode("StateChanged")
    ScriptHost:RemoveOnLocationSectionHandler("location_section_change_handler")
    SLOT_DATA = slot_data
	
	local bosses_goal = Tracker:FindObjectForCode("bosses_goal")
	if bosses_goal then
		bosses_goal.Active = tonumber(slot_data.goal_option) == 1
	end
	REQUIRED_MINICONS = nil
	if slot_data and slot_data.minicon_count ~= nil then
		REQUIRED_MINICONS = tonumber(slot_data.minicon_count)
	end
	UpdateMiniconCounter()
	
	-- Read the Beginner Location option from AP Slot Data
	local beginner_enabled =
		slot_data ~= nil
		and (
			slot_data.add_starting_location == true
			or slot_data.add_starting_location == 1
		)
	local beginner_item =
		Tracker:FindObjectForCode("beginner_location_enabled")
	if beginner_item then
		beginner_item.Active = beginner_enabled
	end
	ForceUpdate()
	local beginner = Tracker:FindObjectForCode("@Beginner Location")
	
    CUR_INDEX = -1
    -- reset locations
    for location_ID, location_array in pairs(LOCATION_MAPPING) do
        for _, location in pairs(location_array) do
            if location then
                if type(location) == "table" then
                    local item_code, item_type, consumable_multiplies = table.unpack(location)
                    ItemUpdate(item_code, item_type, consumable_multiplies, location_ID, true)
                else
                    if location:sub(1, 1) == "@" then
                        ---@type LocationSection
                        local location_obj = Tracker:FindObjectForCode(location) --[[@as LocationSection]]
                        local custom_storage_item = (Tracker:FindObjectForCode("manual_location_storage") --[[@as LuaItem]])
                        .ItemState

                        if location_obj then
                            LocationUpdate(location_obj, custom_storage_item, location_ID, true)
                        end
                    else
                        ---@cast location JsonItem
                        ItemUpdate(location, nil, nil, location_ID, true)
                    end
                end
            end
        end
    end
    -- reset items
    for item_ID, item_array in pairs(ITEM_MAPPING) do
        for _, item_pair in pairs(item_array) do
            local item_code = item_pair[1]
            local item_type = item_pair[2]
            local consumable_multiplier = tonumber(item_pair[3]) or 1
            -- print("on clear", item_code, item_type)
			---@type JsonItem
            local item_obj = Tracker:FindObjectForCode(item_code) --[[@as JsonItem]]
            if item_obj then
                ItemUpdate(item_obj, item_type, consumable_multiplier, item_ID, true)
            end
        end
    end
    PLAYER_ID = Archipelago.PlayerNumber or -1
    TEAM_NUMBER = Archipelago.TeamNumber or 0
    SLOT_DATA = slot_data
	
	
	
    -- if Tracker:FindObjectForCode("autofill_settings").Active == true then
    --     AutoFill(slot_data)
    -- end
    -- print(PLAYER_ID, TEAM_NUMBER)
    if Archipelago.PlayerNumber > -1 then
        if #ALL_LOCATIONS > 0 then
            ALL_LOCATIONS = {}
        end
        for _, value in pairs(Archipelago.MissingLocations) do
            table.insert(ALL_LOCATIONS, #ALL_LOCATIONS + 1, value)
        end

        for _, value in pairs(Archipelago.CheckedLocations) do
            table.insert(ALL_LOCATIONS, #ALL_LOCATIONS + 1, value)
        end
		
		-- Subscribe to all seven boss values.
		local boss_keys = {}

		for boss_index = 0, 6 do
			local key = string.format(
				"tf04_%s_%s_%s_Boss_%d",
				tostring(Archipelago.Seed),
				tostring(Archipelago.TeamNumber),
				tostring(Archipelago.PlayerNumber),
				boss_index
			)

			BOSS_STORAGE_KEYS[key] = boss_index
			BOSS_STATES[boss_index] = false
			BOSS_STATES_RECEIVED[boss_index] = false

			table.insert(boss_keys, key)
		end

		-- Subscribe to changes and retrieve the current saved values.
		
		Archipelago:SetNotify(boss_keys)
		Archipelago:Get(boss_keys)
		
        HINTS_ID = "_read_hints_"..TEAM_NUMBER.."_"..PLAYER_ID
        Archipelago:SetNotify({HINTS_ID})
        Archipelago:Get({HINTS_ID})
    end
    ScriptHost:AddOnFrameHandler("load handler", OnFrameHandler)
    MANUAL_CHECKED = true
end

---Run every time an Item gets sent to the connected slot
---@param index integer running index for the items the connected slot has received so far
---@param item_id integer ID of the received item, matching the game's datapackage ID
---@param item_name string name of the item from the datapackage for the given itemID
---@param player_number integer slotnumber of the player who picked up the item
function OnItem(index, item_id, item_name, player_number)
    if index <= CUR_INDEX then
        return
    end
    local is_local = player_number == Archipelago.PlayerNumber
    CUR_INDEX = index;
    local item = ITEM_MAPPING[item_id]
    if not item or not item[1] then
        --print(string.format("OnItem: could not find item mapping for id %s", item_id))
        return
    end
    for _, item_pair in pairs(item) do
        local item_code = item_pair[1]
        local item_type = item_pair[2]
        local consumable_multiplier = tonumber(item_pair[3]) or 1

        local item_obj = Tracker:FindObjectForCode(item_code)
        if item_obj then
            ItemUpdate(item_code, item_type, consumable_multiplier, item_id, false)
        else
            print(string.format("OnItem: could not find object for code %s", item_code))
        end
    end
end

---called when a location gets cleared
---@param location_id integer ID of the location cleared from the datapackage
---@param location_name string name of the location cleared from the datapackage
function OnLocation(location_id, location_name)
    MANUAL_CHECKED = false
	
	-- Boss locations are handled separately.
    -- Only use special boss handling for the Bosses goal.
    if SLOT_DATA
        and tonumber(SLOT_DATA.goal_option) == 1
        and BOSS_LOCATION_TO_INDEX[location_id] ~= nil then

        UpdateBossLocation(location_id)
        MANUAL_CHECKED = true
        return
    end
	
    local location_array = LOCATION_MAPPING[location_id]
    if not location_array or not location_array[1] then
        print(string.format("OnLocation: could not find location mapping for id %s", location_id))
        return
    end

    for _, location in pairs(location_array) do
        if location then
            if type(location) == "table" then
                local item_code, item_type, consumable_multiplier = table.unpack(location)
                ItemUpdate(item_code, item_type, consumable_multiplier, location_id, false)
            else

                if location:sub(1, 1) == "@" then
                    ---@type LocationSection
                    local location_obj = Tracker:FindObjectForCode(location) --[[@as LocationSection]]
                    if location_obj then
						LocationUpdate(location_obj, custom_storage_item, location_id, false)
                    else
                        print(string.format("OnLocation: could not find location_object for code %s", location))
                    end
                else
                    ItemUpdate(location, nil, nil, location_id, false)
                end
            end
        end
    end
    MANUAL_CHECKED = true
end

-- this Autofill function is meant as an example on how to do the reading from slot_data
-- and mapping the values to your own settings
-- ---@param slot_data table
-- function AutoFill(slot_data)
--     -- print(DumpTable(slot_data))

--     mapToggle={[0]=0,[1]=1,[2]=1,[3]=1,[4]=1}
--     mapToggleReverse={[0]=1,[1]=0,[2]=0,[3]=0,[4]=0}
--     mapTripleReverse={[0]=2,[1]=1,[2]=0}

--     slotCodes = {
--         map_name = {code="", mapping=mapToggle...}
--     }
--     -- print(Tracker:FindObjectForCode("autofill_settings").Active)
--     if Tracker:FindObjectForCode("autofill_settings").Active == true then
--         for settings_name, settings_value in pairs(slot_data) do
--             -- print(k, v)
--             if slotCodes[settings_name] then
--                 item = Tracker:FindObjectForCode(slotCodes[settings_name].code)
--                 if item.Type == "toggle" then
--                     item.Active = slotCodes[settings_name].mapping[settings_value]
--                 else
--                     -- print(k,v,Tracker:FindObjectForCode(slotCodes[k].code).CurrentStage, slotCodes[k].mapping[v])
--                     item.CurrentStage = slotCodes[settings_name].mapping[settings_value]
--                 end
--             end
--         end
--     end
-- end

---@class APHintMessage
---@field receiving_player integer
---@field finding_player integer
---@field location integer
---@field item integer
---@field found boolean
---@field entrance string
---@field item_flags 0|1|2|3|4|5|6|7
---@field status 0|10|20|30|40

---function to update the Highlight of a LocationSection to represent the status of the hint that is present
---for that LocationSection
---@param locationID integer ID of the locations the hint is being given for
---@param status 0|10|20|30|40|100|101|102|103|104|105|106|107 status to determine the color of the hint glow
local function UpdateHints(locationID, status) -->
    if Highlight then
        -- print(locationID, status)
        local location_table = LOCATION_MAPPING[locationID]
        
        -- Safetly stop if the location ID returns nil in location_mapping.lua
        if not location_table then
            print(string.format("UpdateHints: Location ID %s not found in LOCATION_MAPPING. Skipping highlight.", locationID))
            return
        end

        for _, location in ipairs(location_table) do
            if location:sub(1, 1) == "@" then
				---@type LocationSection
                local obj = Tracker:FindObjectForCode(location)

                if obj then
                    if TROLL_PLAYER and HIGHLIGHT_LEVEL[status] == Highlight.Avoid then
                        obj.Highlight = HIGHLIGHT_LEVEL[30]
                    else
                        obj.Highlight = HIGHLIGHT_LEVEL[status]
                    end
                else
                    print(string.format("No object found for code: %s", location))
                end
            end
        end
    end
end

---triggers as AP sends live updates from the server using a given key we subscribed to in Archipelago:SetNotify
---@param key string Name of the key that was used to send the message
---@param value table<integer, APHintMessage>
---@param old_value table<integer, APHintMessage>
function OnNotify(key, value, old_value)
    print("OnNotify", key, value, old_value)
	
	
	 -- Handle live boss DataStorage updates.
    local boss_index = BOSS_STORAGE_KEYS[key]
    if boss_index ~= nil then
        if type(value) == "boolean" then
            BOSS_STATES[boss_index] = value
            BOSS_STATES_RECEIVED[boss_index] = true

            -- Location ID = 9001 + boss index.
            UpdateBossLocation(9001 + boss_index)
            ForceUpdate()
        end

        return
    end
	
    if value ~= old_value and key == HINTS_ID then
        Tracker.BulkUpdate = true
        for _, hint in ipairs(value) do
            if hint.finding_player == Archipelago.PlayerNumber then
                if hint.status == 0 then
                    UpdateHints(hint.location, 100+hint.item_flags)
                else
                    UpdateHints(hint.location, hint.status)
                end
            end
        end
        Tracker.BulkUpdate = false
    end
end

---triggers on connecting to AP when we receive this message from the server after providing a given key to Archipelago:Get
---@param key string Name of the key that was used to send the message
---@param value table<integer, APHintMessage>
function OnNotifyLaunch(key, value)
	
	-- Handle the initial boss values returned by Archipelago:Get().
    local boss_index = BOSS_STORAGE_KEYS[key]

    if boss_index ~= nil then
        if type(value) == "boolean" then
            BOSS_STATES[boss_index] = value
            BOSS_STATES_RECEIVED[boss_index] = true

            UpdateBossLocation(9001 + boss_index)
            ForceUpdate()
        end

        return
    end
    if key == HINTS_ID then
        Tracker.BulkUpdate = true
        for _, hint in ipairs(value) do
            if hint.finding_player == Archipelago.PlayerNumber then
                if hint.status == 0 then
                    UpdateHints(hint.location, 100+hint.item_flags)
                else
                    UpdateHints(hint.location, hint.status)
                end
            end
        end
        Tracker.BulkUpdate = false
    end
end

-------------------
---this section is only for special things that are time of day or day of year dependant if you really want to do stuff
---stuff like this

---@param start_date number BuildTimeObj() return aka unix timestamp
---@param end_date number BuildTimeObj() return aka unix timestamp
---@param target_date number BuildTimeObj() return aka unix timestamp
function CheckDateRange(start_date, end_date, target_date)
    local one_day = 86400
    local check_result = false
    for day_obj = start_date, end_date, one_day do
        check_result = CheckDate(day_obj, target_date)
        if check_result then
            return true
        end
    end
end

---@param target_date number BuildTimeObj() return aka unix timestamp
---@param reference_time number? BuildTimeObj() return aka unix timestamp
function CheckDate(reference_time, target_date)
    local today = os.date("*t")
    local reference_day =  os.date("*t", target_date)
    if reference_time then
        today = os.date("*t", reference_time)
    end
    return today.year == reference_day.year and
    today.month == reference_day.month and
    today.day == reference_day.day
end

---helper function to return a date object for the provided day
---@param year number?
---@param month number?
---@param day number?
---@param hour number?
---@param minute number?
---@param second number?
---@return integer
function BuildTimeObj(year, month, day, hour, minute, second)
    local today = os.date("*t", os.time())
    return os.time(
        {
            year = year or today.year,
            month = month or today.month,
            day = day or today.day,
            hour = hour or 0,
            min = minute or 0,
            sec = second or 0
        }
    )
end
-------------------


--doc
--hint layout
-- {
--     ["receiving_player"] = 1,
--     ["class"] = Hint,
--     ["finding_player"] = 1,
--     ["location"] = 67361,
--     ["found"] = false,
--     ["item_flags"] = 2, --bitflag --> 0=filler, 1=progression, 2=useful, 4=trap
--     ["status"] = 40, --bitflag --> 0=Unspecified, 10=NoPriority, 20=Avoid, 30=Priority, 40=None
--     ["entrance"] = ,
--     ["item"] = 66062,
-- }


----------
---remnant from when poptracker had issues loading some larger/heavy packs
--function OnClearHandler(slot_data)
--    local clear_timer = os.clock()
--
--    ScriptHost:RemoveWatchForCode("StateChange")
--    -- Disable tracker updates.
--    Tracker.BulkUpdate = true
--    -- Use a protected call so that tracker updates always get enabled again, even if an error occurred.
--    local ok, err = pcall(OnClear, slot_data)
--    -- Enable tracker updates again.
--    if ok then
--        -- Defer re-enabling tracker updates until the next frame, which doesn't happen until all received items/cleared
--        -- locations from AP have been processed.
--        local handlerName = "AP OnClearHandler"
--        local function frameCallback()
--            ScriptHost:AddWatchForCode("StateChange", "*", StateChanged)
--            ScriptHost:RemoveOnFrameHandler(handlerName)
--            Tracker.BulkUpdate = false
--            ForceUpdate()
--            print(string.format("Time taken total: %.2f", os.clock() - clear_timer))
--        end
--        ScriptHost:AddOnFrameHandler(handlerName, frameCallback)
--    else
--        Tracker.BulkUpdate = false
--        print("Error: OnClear failed:")
--        print(err)
--    end
--end
